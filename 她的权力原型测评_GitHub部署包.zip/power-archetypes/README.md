# 她的权力原型 · 测评网页

6 题测出用户的「掌权女性基因」，输出主/辅原型组合比例 + 五维配比 + 2 张人物参照卡，支持保存与转发。

## 部署到 GitHub Pages（零命令）

1. 登录 GitHub → 右上角 `+` → **New repository**
2. Repository name 填 `power-archetypes`，选 **Public**，勾选 **Add a README file** → Create repository
3. 进入仓库 → **Add file** → **Upload files** → 把本目录的 `index.html` 拖进去 → Commit changes
4. 仓库顶部 **Settings** → 左侧 **Pages**
   - Source：`Deploy from a branch`
   - Branch：`main` / `/ (root)` → Save
5. 等 1-3 分钟，顶部出现 **Your site is live at https://你的用户名.github.io/power-archetypes/**

> 文件名必须保持 `index.html`，否则访问地址会带一长串中文文件名。

## 上线前必换两处

1. **人物肖像**：网页里是 emoji 占位（👑🏹⚗◈❋），换成公版历史画像 / 自绘插画 / 正版图库图
   —— 改 `index.html` 中 `A.ruler.icon` 等字段，或直接替换为 `<img>` 标签
2. **收款方式**：本版本走小红书店铺自动收款，网页内无二维码，无需额外配置

## 接入小红书商品

商品创建页 → 发货方式选「无需邮寄/虚拟资料」→ 自动发货栏填入：

```
测评链接：https://你的用户名.github.io/power-archetypes/
说明：手机浏览器打开，6 题约 2 分钟，完成后长按保存报告截图。
```

## 合规提醒

- 页面底部已内置免责声明，不要删除
- 商品标题/详情只写「测评/原型/参照卡」，不写「心理诊断」「性格测试」
- 类目选「电子资源」
- 人物履历为简化表述，非史实考据
